CREATE TRIGGER changefoodsum1
  AFTER INSERT
  ON foodcheck
  FOR EACH ROW
  begin
update food set foodBanlance=foodBanlance-new.foodNum where foodNumber=new.foodNumber;
END;

