CREATE VIEW foodcheckhavename AS
  SELECT DISTINCT
    `hotpot`.`foodcheck`.`businessNumber` AS `businessNumber`,
    `hotpot`.`food`.`foodName`            AS `foodName`,
    `hotpot`.`foodcheck`.`customerNumber` AS `customerNumber`,
    `hotpot`.`foodcheck`.`foodNum`        AS `foodNum`,
    `hotpot`.`foodcheck`.`checkPrice`     AS `checkPrice`,
    `hotpot`.`foodcheck`.`checkDate`      AS `checkDate`
  FROM `hotpot`.`foodcheck`
    JOIN `hotpot`.`food`
  WHERE (`hotpot`.`food`.`foodNumber` = `hotpot`.`foodcheck`.`foodNumber`);

