CREATE VIEW meat AS
  SELECT
    `hotpot`.`food`.`foodNumber`   AS `foodNumber`,
    `hotpot`.`food`.`foodName`     AS `foodName`,
    `hotpot`.`food`.`foodPhoto`    AS `foodPhoto`,
    `hotpot`.`food`.`foodType`     AS `foodType`,
    `hotpot`.`food`.`foodPrice`    AS `foodPrice`,
    `hotpot`.`food`.`foodBanlance` AS `foodBanlance`
  FROM `hotpot`.`food`
  WHERE (`hotpot`.`food`.`foodType` = 'meat');

