CREATE VIEW foodcheckplus AS
  SELECT
    `hotpot`.`food`.`foodName`            AS `foodName`,
    `hotpot`.`foodcheck`.`checkNumber`    AS `checkNumber`,
    `hotpot`.`foodcheck`.`businessNumber` AS `businessNumber`,
    `hotpot`.`foodcheck`.`customerNumber` AS `customerNumber`,
    `hotpot`.`foodcheck`.`foodNumber`     AS `foodNumber`,
    `hotpot`.`foodcheck`.`foodNum`        AS `foodNum`,
    `hotpot`.`foodcheck`.`checkPrice`     AS `checkPrice`,
    `hotpot`.`foodcheck`.`checkDate`      AS `checkDate`,
    `hotpot`.`food`.`foodPhoto`           AS `foodPhoto`
  FROM (`hotpot`.`food`
    JOIN `hotpot`.`foodcheck`)
  WHERE (`hotpot`.`food`.`foodNumber` = `hotpot`.`foodcheck`.`foodNumber`);

