CREATE TRIGGER changefoodsum
  AFTER INSERT
  ON business
  FOR EACH ROW
  begin
if new.businessType='food' THEN
update food set foodBanlance=foodBanlance-new.foodSum where foodNumber=new.foodNumber;
end if;
END;

