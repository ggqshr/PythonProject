CREATE TRIGGER t_insertusers_account
  AFTER INSERT
  ON users
  FOR EACH ROW
  BEGIN
insert into account(account_money,userId) values(0,new.userId);
END;

