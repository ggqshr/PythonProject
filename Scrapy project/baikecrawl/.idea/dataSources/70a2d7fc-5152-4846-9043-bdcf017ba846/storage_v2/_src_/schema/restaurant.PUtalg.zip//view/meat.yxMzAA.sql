CREATE VIEW meat AS
  (SELECT
     `restaurant`.`food`.`foodNumber`   AS `foodNumber`,
     `restaurant`.`food`.`foodName`     AS `foodName`,
     `restaurant`.`food`.`foodType`     AS `foodType`,
     `restaurant`.`food`.`foodPrice`    AS `foodPrice`,
     `restaurant`.`food`.`foodBanlance` AS `foodBanlance`
   FROM `restaurant`.`food`
   WHERE (`restaurant`.`food`.`foodType` = 'meat'));

