CREATE VIEW businessplus AS
  SELECT
    `hotpot`.`business`.`businessNumber` AS `businessNumber`,
    `hotpot`.`business`.`customerNumber` AS `customerNumber`,
    `hotpot`.`business`.`businessType`   AS `businessType`,
    `hotpot`.`business`.`foodNumber`     AS `foodNumber`,
    `hotpot`.`business`.`comboNumber`    AS `comboNumber`,
    `hotpot`.`business`.`foodSum`        AS `foodSum`,
    `hotpot`.`business`.`businessMoney`  AS `businessMoney`,
    `hotpot`.`business`.`businessDate`   AS `businessDate`,
    `hotpot`.`business`.`businessScore`  AS `businessScore`,
    `hotpot`.`combo`.`comboName`         AS `comboName`,
    `hotpot`.`combo`.`comboPhoto`        AS `comboPhoto`
  FROM (`hotpot`.`business`
    JOIN `hotpot`.`combo`)
  WHERE ((`hotpot`.`business`.`comboNumber` = `hotpot`.`combo`.`comboNumber`) OR
         (`hotpot`.`business`.`businessType` = 'food'));

