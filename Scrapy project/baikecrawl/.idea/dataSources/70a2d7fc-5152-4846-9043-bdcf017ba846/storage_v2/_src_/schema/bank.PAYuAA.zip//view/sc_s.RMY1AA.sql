CREATE VIEW sc_s AS
  SELECT
    `bank`.`business`.`businessNumber` AS `businessNumber`,
    `bank`.`business`.`custNumber`     AS `custNumber`,
    `bank`.`business`.`businessType`   AS `businessType`,
    `bank`.`business`.`businessMoney`  AS `businessMoney`,
    `bank`.`business`.`businessDate`   AS `businessDate`
  FROM `bank`.`business`;

