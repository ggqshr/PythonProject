CREATE TRIGGER updateScore
  AFTER UPDATE
  ON business
  FOR EACH ROW
  begin
if new.businessType='combo' THEN
update combo set comboScore=(new.businessScore+comboScore*scoreNum)/(scoreNum+1) where comboNumber=new.comboNumber;
update combo set scoreNum = scoreNum+1 where comboNumber = new . comboNumber;
end if;
END;

