CREATE VIEW info AS
  (SELECT
     `c`.`name`  AS `name`,
     `b`.`bname` AS `bname`
   FROM `sql_text`.`books` `b`
     JOIN `sql_text`.`card` `c`
     JOIN `sql_text`.`borrow` `bw`
   WHERE ((`bw`.`cno` = `c`.`cno`) AND (`bw`.`bno` = `b`.`bno`)));

